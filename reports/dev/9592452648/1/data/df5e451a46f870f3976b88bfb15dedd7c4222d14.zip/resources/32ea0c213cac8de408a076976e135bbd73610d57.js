/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 3906:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   proxyWorkerUtils: () => (/* binding */ proxyWorkerUtils)
/* harmony export */ });
/* unused harmony export toAccountId */
/* harmony import */ var _polkadot_util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(79);
/* harmony import */ var _polkadot_util_crypto__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(68);
/* harmony import */ var _substrate_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1021);
function _define_property(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true})}else{obj[key]=value}return obj}var proxyWorkerUtils={toAccountId:toAccountId,isSameProxy:isSameProxy,isSameProxied:isSameProxied,isApiConnected:isApiConnected,isDelayedProxy:isDelayedProxy,getKnownChain:getKnownChain};function toAccountId(address){try{return (0,_polkadot_util__WEBPACK_IMPORTED_MODULE_1__.u8aToHex)((0,_polkadot_util_crypto__WEBPACK_IMPORTED_MODULE_2__.decodeAddress)(address))}catch(e){return"0x00"}}function isSameProxy(oldProxy,newProxy){return oldProxy.accountId===newProxy.accountId&&oldProxy.proxiedAccountId===newProxy.proxiedAccountId&&oldProxy.chainId===newProxy.chainId&&oldProxy.proxyType===newProxy.proxyType&&oldProxy.delay===newProxy.delay}function isSameProxied(oldProxy,newProxy){return oldProxy.accountId===newProxy.accountId&&oldProxy.proxyAccountId===newProxy.proxyAccountId&&oldProxy.chainId===newProxy.chainId&&oldProxy.proxyType===newProxy.proxyType&&oldProxy.delay===newProxy.delay}function isApiConnected(apis,chainId){var api=apis[chainId];return Boolean(api===null||api===void 0?void 0:api.isConnected)}function isDelayedProxy(proxy){return proxy.delay!==0}var MainChains={POLKADOT:"0x91b171bb158e2d3848fa23a9f1c25182fb8e20313b2c1eb49219da7a70ce90c3",KUSAMA:"0xb0a8d493285c2df73290dfb7e61f870f17b41801197a149ca93654499ea3dafe"};var _obj;var KnownChains=(_obj={},_define_property(_obj,MainChains.POLKADOT,_substrate_connect__WEBPACK_IMPORTED_MODULE_0__.WellKnownChain.polkadot),_define_property(_obj,MainChains.KUSAMA,_substrate_connect__WEBPACK_IMPORTED_MODULE_0__.WellKnownChain.ksmcc3),_obj);function getKnownChain(chainId){return KnownChains[chainId]}

/***/ }),

/***/ 3905:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony exports proxyWorker, state */
/* harmony import */ var _remote_ui_rpc__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3260);
/* harmony import */ var _polkadot_rpc_provider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1078);
/* harmony import */ var _polkadot_rpc_provider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1266);
/* harmony import */ var _polkadot_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1024);
/* harmony import */ var _substrate_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1021);
/* harmony import */ var _lib_worker_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3906);
/* harmony import */ var _shared_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(121);
function _array_like_to_array(arr,len){if(len==null||len>arr.length)len=arr.length;for(var i=0,arr2=new Array(len);i<len;i++)arr2[i]=arr[i];return arr2}function _array_with_holes(arr){if(Array.isArray(arr))return arr}function asyncGeneratorStep(gen,resolve,reject,_next,_throw,key,arg){try{var info=gen[key](arg);var value=info.value}catch(error){reject(error);return}if(info.done){resolve(value)}else{Promise.resolve(value).then(_next,_throw)}}function _async_to_generator(fn){return function(){var self1=this,args=arguments;return new Promise(function(resolve,reject){var gen=fn.apply(self1,args);function _next(value){asyncGeneratorStep(gen,resolve,reject,_next,_throw,"next",value)}function _throw(err){asyncGeneratorStep(gen,resolve,reject,_next,_throw,"throw",err)}_next(undefined)})}}function _define_property(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true})}else{obj[key]=value}return obj}function _iterable_to_array_limit(arr,i){var _i=arr==null?null:typeof Symbol!=="undefined"&&arr[Symbol.iterator]||arr["@@iterator"];if(_i==null)return;var _arr=[];var _n=true;var _d=false;var _s,_e;try{for(_i=_i.call(arr);!(_n=(_s=_i.next()).done);_n=true){_arr.push(_s.value);if(i&&_arr.length===i)break}}catch(err){_d=true;_e=err}finally{try{if(!_n&&_i["return"]!=null)_i["return"]()}finally{if(_d)throw _e}}return _arr}function _non_iterable_rest(){throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}function _object_spread(target){for(var i=1;i<arguments.length;i++){var source=arguments[i]!=null?arguments[i]:{};var ownKeys=Object.keys(source);if(typeof Object.getOwnPropertySymbols==="function"){ownKeys=ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym){return Object.getOwnPropertyDescriptor(source,sym).enumerable}))}ownKeys.forEach(function(key){_define_property(target,key,source[key])})}return target}function ownKeys(object,enumerableOnly){var keys=Object.keys(object);if(Object.getOwnPropertySymbols){var symbols=Object.getOwnPropertySymbols(object);if(enumerableOnly){symbols=symbols.filter(function(sym){return Object.getOwnPropertyDescriptor(object,sym).enumerable})}keys.push.apply(keys,symbols)}return keys}function _object_spread_props(target,source){source=source!=null?source:{};if(Object.getOwnPropertyDescriptors){Object.defineProperties(target,Object.getOwnPropertyDescriptors(source))}else{ownKeys(Object(source)).forEach(function(key){Object.defineProperty(target,key,Object.getOwnPropertyDescriptor(source,key))})}return target}function _sliced_to_array(arr,i){return _array_with_holes(arr)||_iterable_to_array_limit(arr,i)||_unsupported_iterable_to_array(arr,i)||_non_iterable_rest()}function _unsupported_iterable_to_array(o,minLen){if(!o)return;if(typeof o==="string")return _array_like_to_array(o,minLen);var n=Object.prototype.toString.call(o).slice(8,-1);if(n==="Object"&&o.constructor)n=o.constructor.name;if(n==="Map"||n==="Set")return Array.from(n);if(n==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return _array_like_to_array(o,minLen)}function _ts_generator(thisArg,body){var f,y,t,g,_={label:0,sent:function(){if(t[0]&1)throw t[1];return t[1]},trys:[],ops:[]};return g={next:verb(0),"throw":verb(1),"return":verb(2)},typeof Symbol==="function"&&(g[Symbol.iterator]=function(){return this}),g;function verb(n){return function(v){return step([n,v])}}function step(op){if(f)throw new TypeError("Generator is already executing.");while(_)try{if(f=1,y&&(t=op[0]&2?y["return"]:op[0]?y["throw"]||((t=y["return"])&&t.call(y),0):y.next)&&!(t=t.call(y,op[1])).done)return t;if(y=0,t)op=[op[0]&2,t.value];switch(op[0]){case 0:case 1:t=op;break;case 4:_.label++;return{value:op[1],done:false};case 5:_.label++;y=op[1];op=[0];continue;case 7:op=_.ops.pop();_.trys.pop();continue;default:if(!(t=_.trys,t=t.length>0&&t[t.length-1])&&(op[0]===6||op[0]===2)){_=0;continue}if(op[0]===3&&(!t||op[1]>t[0]&&op[1]<t[3])){_.label=op[1];break}if(op[0]===6&&_.label<t[1]){_.label=t[1];t=op;break}if(t&&_.label<t[2]){_.label=t[2];_.ops.push(op);break}if(t[2])_.ops.pop();_.trys.pop();continue}op=body.call(thisArg,_)}catch(e){op=[6,e];y=0}finally{f=t=0}if(op[0]&5)throw op[1];return{value:op[0]?op[1]:void 0,done:true}}}var proxyWorker={initConnection:initConnection,getProxies:getProxies,disconnect:disconnect};var state={apis:{}};var InitConnectionsResult={SUCCESS:"success",FAILED:"failed"};function initConnection(chain,connection){return new Promise(function(resolve,reject){if(!chain){console.log("proxy-worker: chain not provided");reject();return}try{var provider;if(!connection||connection.connectionType===_shared_core__WEBPACK_IMPORTED_MODULE_2__.ConnectionType.AUTO_BALANCE){provider=new _polkadot_rpc_provider__WEBPACK_IMPORTED_MODULE_3__.WsProvider(chain.nodes.concat((connection===null||connection===void 0?void 0:connection.customNodes)||[]).map(function(node){return node.url}))}else if(connection.connectionType===_shared_core__WEBPACK_IMPORTED_MODULE_2__.ConnectionType.RPC_NODE){var _connection_activeNode;provider=new _polkadot_rpc_provider__WEBPACK_IMPORTED_MODULE_3__.WsProvider([((_connection_activeNode=connection.activeNode)===null||_connection_activeNode===void 0?void 0:_connection_activeNode.url)||""])}else if(connection.connectionType===_shared_core__WEBPACK_IMPORTED_MODULE_2__.ConnectionType.LIGHT_CLIENT){try{var knownChainId=_lib_worker_utils__WEBPACK_IMPORTED_MODULE_1__.proxyWorkerUtils.getKnownChain(chain.chainId);if(knownChainId){provider=new _polkadot_rpc_provider__WEBPACK_IMPORTED_MODULE_4__.ScProvider(_substrate_connect__WEBPACK_IMPORTED_MODULE_0__,knownChainId);provider.connect()}}catch(e){console.log("proxy-worker: light client not connected",e);reject();return}}if(!provider){console.log("proxy-worker: provider not connected");reject();return}provider.on("connected",_async_to_generator(function(){var _,_1;return _ts_generator(this,function(_state){switch(_state.label){case 0:_=state.apis;_1=chain.chainId;return[4,_polkadot_api__WEBPACK_IMPORTED_MODULE_5__.ApiPromise.create({provider:provider,throwOnConnect:true,throwOnUnknown:true})];case 1:_[_1]=_state.sent();console.log("proxy-worker: provider connected successfully");resolve(InitConnectionsResult.SUCCESS);return[2]}})}))}catch(e){console.log("proxy-worker: error in initConnection",e);reject()}})}function disconnect(chainId){return _disconnect.apply(this,arguments)}function _disconnect(){_disconnect=_async_to_generator(function(chainId){return _ts_generator(this,function(_state){switch(_state.label){case 0:if(!_lib_worker_utils__WEBPACK_IMPORTED_MODULE_1__.proxyWorkerUtils.isApiConnected(state.apis,chainId))return[2];console.log("proxy-worker: disconnecting from chainId",chainId);return[4,state.apis[chainId].disconnect()];case 1:_state.sent();return[2]}})});return _disconnect.apply(this,arguments)}function getProxies(_){return _getProxies.apply(this,arguments)}function _getProxies(){_getProxies=_async_to_generator(function(param){var chainId,accountsForProxy,accountsForProxied,proxiedAccounts,proxies,api,existingProxies,proxiesToAdd,existingProxiedAccounts,proxiedAccountsToAdd,deposits,entries,e,proxiesToRemove,proxiedAccountsToRemove;return _ts_generator(this,function(_state){switch(_state.label){case 0:chainId=param.chainId,accountsForProxy=param.accountsForProxy,accountsForProxied=param.accountsForProxied,proxiedAccounts=param.proxiedAccounts,proxies=param.proxies;api=state.apis[chainId];existingProxies=[];proxiesToAdd=[];existingProxiedAccounts=[];proxiedAccountsToAdd=[];deposits={chainId:chainId,deposits:{}};if(!api||!api.query.proxy){return[2,{proxiesToAdd:proxiesToAdd,proxiesToRemove:[],proxiedAccountsToAdd:proxiedAccountsToAdd,proxiedAccountsToRemove:[],deposits:deposits}]}_state.label=1;case 1:_state.trys.push([1,3,,4]);return[4,api.query.proxy.proxies.entries()];case 2:entries=_state.sent();entries.forEach(function(param){var _param=_sliced_to_array(param,2),key=_param[0],value=_param[1];try{var proxyData=value.toHuman();var proxiedAccountId=key.args[0].toHex();proxyData[0].forEach(function(account){var newProxy={chainId:chainId,proxiedAccountId:proxiedAccountId,accountId:_lib_worker_utils__WEBPACK_IMPORTED_MODULE_1__.proxyWorkerUtils.toAccountId(account===null||account===void 0?void 0:account.delegate),proxyType:account.proxyType,delay:Number(account.delay)};var needToAddProxiedAccount=accountsForProxied[newProxy.accountId]&&!_lib_worker_utils__WEBPACK_IMPORTED_MODULE_1__.proxyWorkerUtils.isDelayedProxy(newProxy);if(needToAddProxiedAccount){var proxiedAccount=_object_spread_props(_object_spread({},newProxy),{proxyAccountId:newProxy.accountId,accountId:newProxy.proxiedAccountId,proxyVariant:_shared_core__WEBPACK_IMPORTED_MODULE_2__.ProxyVariant.NONE});var doesProxiedAccountExist=proxiedAccounts.some(function(oldProxy){return _lib_worker_utils__WEBPACK_IMPORTED_MODULE_1__.proxyWorkerUtils.isSameProxied(oldProxy,proxiedAccount)});console.log("proxy-worker ".concat(api.genesisHash,": found \uD83D\uDFE3 proxied account: "),proxiedAccount);if(!doesProxiedAccountExist){console.log("proxy-worker ".concat(api.genesisHash,": \uD83D\uDFE3 proxied should be added: "),proxiedAccount);proxiedAccountsToAdd.push(proxiedAccount)}existingProxiedAccounts.push(proxiedAccount)}if(needToAddProxiedAccount){deposits.deposits[proxiedAccountId]=proxyData[1]}});proxyData[0].forEach(function(account){var newProxy={chainId:chainId,proxiedAccountId:proxiedAccountId,accountId:_lib_worker_utils__WEBPACK_IMPORTED_MODULE_1__.proxyWorkerUtils.toAccountId(account===null||account===void 0?void 0:account.delegate),proxyType:account.proxyType,delay:Number(account.delay)};var needToAddProxyAccount=accountsForProxy[proxiedAccountId]||proxiedAccountsToAdd.some(function(p){return p.accountId===proxiedAccountId});var doesProxyExist=proxies.some(function(oldProxy){return _lib_worker_utils__WEBPACK_IMPORTED_MODULE_1__.proxyWorkerUtils.isSameProxy(oldProxy,newProxy)});if(needToAddProxyAccount){console.log("proxy-worker ".concat(api.genesisHash,": found \uD83D\uDD35 proxy : "),newProxy);if(!doesProxyExist){console.log("proxy-worker ".concat(api.genesisHash,": \uD83D\uDD35 proxy  should be added: "),newProxy);proxiesToAdd.push(newProxy)}existingProxies.push(newProxy)}if(needToAddProxyAccount){deposits.deposits[proxiedAccountId]=proxyData[1]}})}catch(e){console.log("proxy-worker ".concat(api.genesisHash,": proxy error"),e)}});return[3,4];case 3:e=_state.sent();console.log("proxy-worker ".concat(api.genesisHash,": error in getProxies"),e);return[3,4];case 4:proxiesToRemove=proxies.filter(function(p){return!existingProxies.some(function(ep){return _lib_worker_utils__WEBPACK_IMPORTED_MODULE_1__.proxyWorkerUtils.isSameProxy(p,ep)})});console.log("proxy-worker ".concat(api.genesisHash,": \uD83D\uDD35 proxy accounts to remove: "),proxiesToRemove);proxiedAccountsToRemove=Object.values(proxiedAccounts).filter(function(p){return!existingProxiedAccounts.some(function(ep){return ep.accountId===p.accountId&&ep.chainId===p.chainId&&ep.proxyAccountId===p.proxyAccountId&&ep.delay===p.delay&&ep.proxyType===p.proxyType})});console.log("proxy-worker ".concat(api.genesisHash,": \uD83D\uDFE3 proxied accounts to remove: "),proxiedAccountsToRemove);return[2,{proxiesToAdd:proxiesToAdd,proxiesToRemove:proxiesToRemove,proxiedAccountsToAdd:proxiedAccountsToAdd,proxiedAccountsToRemove:proxiedAccountsToRemove,deposits:deposits}]}})});return _getProxies.apply(this,arguments)}var endpoint=(0,_remote_ui_rpc__WEBPACK_IMPORTED_MODULE_6__.createEndpoint)(self);endpoint.expose({initConnection:initConnection,getProxies:getProxies,disconnect:disconnect});console.log("proxy-worker: worker started successfully");

/***/ }),

/***/ 121:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ConnectionType: () => (/* reexport safe */ _types_connection__WEBPACK_IMPORTED_MODULE_8__.ConnectionType),
/* harmony export */   ProxyVariant: () => (/* reexport safe */ _types_proxy__WEBPACK_IMPORTED_MODULE_10__.ProxyVariant)
/* harmony export */ });
/* harmony import */ var _model_kernel_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(122);
/* harmony import */ var _types_general__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(123);
/* harmony import */ var _types_utility__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(124);
/* harmony import */ var _types_wallet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(125);
/* harmony import */ var _types_account__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(126);
/* harmony import */ var _types_asset__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(118);
/* harmony import */ var _types_balance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(127);
/* harmony import */ var _types_chain__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(128);
/* harmony import */ var _types_connection__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(129);
/* harmony import */ var _types_stake__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(130);
/* harmony import */ var _types_proxy__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(131);
/* harmony import */ var _types_notification__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(132);
/* harmony import */ var _types_substrate__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(133);
/* harmony import */ var _types_transaction__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(134);
/* harmony import */ var _types_referendum__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(135);
/* harmony import */ var _types_voting__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(136);


/***/ }),

/***/ 122:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony export kernelModel */
/* harmony import */ var effector__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(42);
var appStarted=(0,effector__WEBPACK_IMPORTED_MODULE_0__.createEvent)();var kernelModel={events:{appStarted:appStarted}};

/***/ }),

/***/ 126:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony exports AccountType, KeyType */
var AccountType;(function(AccountType){AccountType["BASE"]="base";AccountType["CHAIN"]="chain";AccountType["SHARD"]="shard";AccountType["MULTISIG"]="multisig";AccountType["WALLET_CONNECT"]="wallet_connect";AccountType["PROXIED"]="proxied"})(AccountType||(AccountType={}));var KeyType;(function(KeyType){KeyType["MAIN"]="main";KeyType["PUBLIC"]="pub";KeyType["HOT"]="hot";KeyType["GOVERNANCE"]="governance";KeyType["STAKING"]="staking";KeyType["CUSTOM"]="custom"})(KeyType||(KeyType={}));

/***/ }),

/***/ 118:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony exports StakingType, AssetType */
var StakingType;(function(StakingType){StakingType["RELAYCHAIN"]="relaychain"})(StakingType||(StakingType={}));var AssetType;(function(AssetType){AssetType["ORML"]="orml";AssetType["STATEMINE"]="statemine"})(AssetType||(AssetType={}));

/***/ }),

/***/ 127:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony export LockTypes */
var LockTypes;(function(LockTypes){LockTypes["STAKING"]="0x7374616b696e6720";LockTypes["CONVICTION_VOTE"]="0x7079636f6e766f74"})(LockTypes||(LockTypes={}));

/***/ }),

/***/ 128:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony exports ChainOptions, ExternalType */
var ChainOptions;(function(ChainOptions){ChainOptions["TESTNET"]="testnet";ChainOptions["CROWDLOANS"]="crowdloans";ChainOptions["MULTISIG"]="multisig";ChainOptions["REGULAR_PROXY"]="regular_proxy";ChainOptions["PURE_PROXY"]="pure_proxy";ChainOptions["ETHEREUM_BASED"]="ethereum_based"})(ChainOptions||(ChainOptions={}));var ExternalType;(function(ExternalType){ExternalType["HISTORY"]="history";ExternalType["STAKING"]="staking";ExternalType["CROWDLOANS"]="crowdloans";ExternalType["PROXY"]="proxy";ExternalType["MULTISIG"]="multisig"})(ExternalType||(ExternalType={}));

/***/ }),

/***/ 129:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ConnectionType: () => (/* binding */ ConnectionType)
/* harmony export */ });
/* unused harmony export ConnectionStatus */
var ConnectionType;(function(ConnectionType){ConnectionType["LIGHT_CLIENT"]="LIGHT_CLIENT";ConnectionType["AUTO_BALANCE"]="AUTO_BALANCE";ConnectionType["RPC_NODE"]="RPC_NODE";ConnectionType["DISABLED"]="DISABLED"})(ConnectionType||(ConnectionType={}));var ConnectionStatus;(function(ConnectionStatus){ConnectionStatus["DISCONNECTED"]="DISCONNECTED";ConnectionStatus["CONNECTING"]="CONNECTING";ConnectionStatus["CONNECTED"]="CONNECTED";ConnectionStatus["ERROR"]="ERROR"})(ConnectionStatus||(ConnectionStatus={}));

/***/ }),

/***/ 123:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony exports CryptoType, ChainType, CryptoTypeString, ErrorType */
var CryptoType;(function(CryptoType){CryptoType[CryptoType["SR25519"]=0]="SR25519";CryptoType[CryptoType["ED25519"]=1]="ED25519";CryptoType[CryptoType["ECDSA"]=2]="ECDSA";CryptoType[CryptoType["ETHEREUM"]=3]="ETHEREUM"})(CryptoType||(CryptoType={}));var ChainType;(function(ChainType){ChainType[ChainType["SUBSTRATE"]=0]="SUBSTRATE";ChainType[ChainType["ETHEREUM"]=1]="ETHEREUM"})(ChainType||(ChainType={}));var CryptoTypeString;(function(CryptoTypeString){CryptoTypeString["SR25519"]="SR25519";CryptoTypeString["ED25519"]="ED25519";CryptoTypeString["ECDSA"]="ECDSA";CryptoTypeString["ETHEREUM"]="ETHEREUM"})(CryptoTypeString||(CryptoTypeString={}));var ErrorType;(function(ErrorType){ErrorType["REQUIRED"]="required";ErrorType["VALIDATE"]="validate";ErrorType["PATTERN"]="pattern";ErrorType["MAX_LENGTH"]="maxLength"})(ErrorType||(ErrorType={}));

/***/ }),

/***/ 132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony export NotificationType */
var NotificationType;(function(NotificationType){NotificationType["MULTISIG_CREATED"]="MultisigCreatedNotification";NotificationType["MULTISIG_APPROVED"]="MultisigApprovedNotification";NotificationType["MULTISIG_EXECUTED"]="MultisigExecutedNotification";NotificationType["MULTISIG_CANCELLED"]="MultisigCancelledNotification";NotificationType["PROXY_CREATED"]="ProxyCreatedNotification";NotificationType["PROXY_REMOVED"]="ProxyRemovedNotification"})(NotificationType||(NotificationType={}));

/***/ }),

/***/ 131:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ProxyVariant: () => (/* binding */ ProxyVariant)
/* harmony export */ });
/* unused harmony export ProxyType */
var ProxyType;(function(ProxyType){ProxyType["ANY"]="Any";ProxyType["NON_TRANSFER"]="NonTransfer";ProxyType["STAKING"]="Staking";ProxyType["AUCTION"]="Auction";ProxyType["CANCEL_PROXY"]="CancelProxy";ProxyType["GOVERNANCE"]="Governance";ProxyType["IDENTITY_JUDGEMENT"]="IdentityJudgement";ProxyType["NOMINATION_POOLS"]="NominationPools"})(ProxyType||(ProxyType={}));var ProxyVariant;(function(ProxyVariant){ProxyVariant["NONE"]="none";ProxyVariant["PURE"]="pure";ProxyVariant["REGULAR"]="regular"})(ProxyVariant||(ProxyVariant={}));

/***/ }),

/***/ 135:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony export ReferendumType */
var ReferendumType;(function(ReferendumType){ReferendumType["Rejected"]="rejected";ReferendumType["Approved"]="approved";ReferendumType["Ongoing"]="ongoing";ReferendumType["Cancelled"]="cancelled";ReferendumType["TimedOut"]="timedOut";ReferendumType["Killed"]="killed"})(ReferendumType||(ReferendumType={}));

/***/ }),

/***/ 130:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony export RewardsDestination */
var RewardsDestination;(function(RewardsDestination){RewardsDestination["RESTAKE"]="restake";RewardsDestination["TRANSFERABLE"]="transferable"})(RewardsDestination||(RewardsDestination={}));

/***/ }),

/***/ 133:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony export XcmPallets */
var XcmPallets;(function(XcmPallets){XcmPallets["XTOKENS"]="xTokens";XcmPallets["XCM_PALLET"]="xcmPallet";XcmPallets["POLKADOT_XCM"]="polkadotXcm"})(XcmPallets||(XcmPallets={}));

/***/ }),

/***/ 134:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony exports TransactionType, MultisigTxInitStatus, MultisigTxFinalStatus, WrapperKind */
var TransactionType;(function(TransactionType){TransactionType["TRANSFER"]="transfer";TransactionType["ORML_TRANSFER"]="ormlTransfer";TransactionType["ASSET_TRANSFER"]="assetTransfer";TransactionType["MULTISIG_AS_MULTI"]="multisig_as_multi";TransactionType["MULTISIG_APPROVE_AS_MULTI"]="multisig_approve_as_multi";TransactionType["MULTISIG_CANCEL_AS_MULTI"]="cancel_as_multi";TransactionType["XCM_LIMITED_TRANSFER"]="xcm_limited_reserve_transfer_assets";TransactionType["XCM_TELEPORT"]="xcm_limited_teleport_assets";TransactionType["POLKADOT_XCM_LIMITED_TRANSFER"]="polkadotxcm_limited_reserve_transfer_assets";TransactionType["POLKADOT_XCM_TELEPORT"]="polkadotxcm_limited_teleport_assets";TransactionType["XTOKENS_TRANSFER_MULTIASSET"]="xtokens_transfer_multiasset";TransactionType["BOND"]="bond";TransactionType["STAKE_MORE"]="bondExtra";TransactionType["UNSTAKE"]="unbond";TransactionType["RESTAKE"]="rebond";TransactionType["REDEEM"]="withdrawUnbonded";TransactionType["NOMINATE"]="nominate";TransactionType["BATCH_ALL"]="batchAll";TransactionType["DESTINATION"]="payee";TransactionType["CHILL"]="chill";TransactionType["ADD_PROXY"]="add_proxy";TransactionType["REMOVE_PROXY"]="remove_proxy";TransactionType["PROXY"]="proxy";TransactionType["CREATE_PURE_PROXY"]="create_pure_proxy";TransactionType["REMOVE_PURE_PROXY"]="kill_pure_proxy"})(TransactionType||(TransactionType={}));var MultisigTxInitStatus;(function(MultisigTxInitStatus){MultisigTxInitStatus["SIGNING"]="SIGNING"})(MultisigTxInitStatus||(MultisigTxInitStatus={}));var MultisigTxFinalStatus;(function(MultisigTxFinalStatus){MultisigTxFinalStatus["ESTABLISHED"]="ESTABLISHED";MultisigTxFinalStatus["CANCELLED"]="CANCELLED";MultisigTxFinalStatus["EXECUTED"]="EXECUTED";MultisigTxFinalStatus["ERROR"]="ERROR"})(MultisigTxFinalStatus||(MultisigTxFinalStatus={}));var WrapperKind;(function(WrapperKind){WrapperKind["MULTISIG"]="multisig";WrapperKind["PROXY"]="proxy"})(WrapperKind||(WrapperKind={}));

/***/ }),

/***/ 124:
/***/ (() => {

"use strict";


/***/ }),

/***/ 136:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony exports VotingType, VoteType, Conviction */
var VotingType;(function(VotingType){VotingType["CASTING"]="casting";VotingType["DELEGATING"]="delegating"})(VotingType||(VotingType={}));var VoteType;(function(VoteType){VoteType["Standard"]="standard";VoteType["Split"]="split";VoteType["SplitAbstain"]="split_abstain"})(VoteType||(VoteType={}));var Conviction;(function(Conviction){Conviction["None"]="None";Conviction["Locked1x"]="locked_1x";Conviction["Locked2x"]="locked_2x";Conviction["Locked3x"]="locked_3x";Conviction["Locked4x"]="locked_4x";Conviction["Locked5x"]="locked_5x";Conviction["Locked6x"]="locked_6x"})(Conviction||(Conviction={}));

/***/ }),

/***/ 125:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony exports WalletType, SigningType */
var WalletType;(function(WalletType){WalletType["WATCH_ONLY"]="wallet_wo";WalletType["POLKADOT_VAULT"]="wallet_pv";WalletType["MULTISIG"]="wallet_ms";WalletType["WALLET_CONNECT"]="wallet_wc";WalletType["NOVA_WALLET"]="wallet_nw";WalletType["PROXIED"]="wallet_pxd";WalletType["MULTISHARD_PARITY_SIGNER"]="wallet_mps";WalletType["SINGLE_PARITY_SIGNER"]="wallet_sps"})(WalletType||(WalletType={}));var SigningType;(function(SigningType){SigningType["WATCH_ONLY"]="signing_wo";SigningType["PARITY_SIGNER"]="signing_ps";SigningType["MULTISIG"]="signing_ms";SigningType["POLKADOT_VAULT"]="signing_pv";SigningType["WALLET_CONNECT"]="signing_wc"})(SigningType||(SigningType={}));

/***/ }),

/***/ 66:
/***/ (() => {

/* (ignored) */

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		var execOptions = { id: moduleId, module: module, factory: __webpack_modules__[moduleId], require: __webpack_require__ };
/******/ 		__webpack_require__.i.forEach(function(handler) { handler(execOptions); });
/******/ 		module = execOptions.module;
/******/ 		execOptions.factory.call(module.exports, module, module.exports, execOptions.require);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = __webpack_module_cache__;
/******/ 	
/******/ 	// expose the module execution interceptor
/******/ 	__webpack_require__.i = [];
/******/ 	
/******/ 	// the startup function
/******/ 	__webpack_require__.x = () => {
/******/ 		// Load entry module and return exports
/******/ 		var __webpack_exports__ = __webpack_require__.O(undefined, [1], () => (__webpack_require__(3905)))
/******/ 		__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 		return __webpack_exports__;
/******/ 	};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = (chunkId) => {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks and sibling chunks for the entrypoint
/******/ 		__webpack_require__.u = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + ".renderer-" + __webpack_require__.h() + ".js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript update chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference all chunks
/******/ 		__webpack_require__.hu = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + "." + __webpack_require__.h() + ".hot-update.js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get update manifest filename */
/******/ 	(() => {
/******/ 		__webpack_require__.hmrF = () => ("1411b37dd2d362e9a1e0." + __webpack_require__.h() + ".hot-update.json");
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/getFullHash */
/******/ 	(() => {
/******/ 		__webpack_require__.h = () => ("77d1024c29bceb4142c8")
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hot module replacement */
/******/ 	(() => {
/******/ 		var currentModuleData = {};
/******/ 		var installedModules = __webpack_require__.c;
/******/ 		
/******/ 		// module and require creation
/******/ 		var currentChildModule;
/******/ 		var currentParents = [];
/******/ 		
/******/ 		// status
/******/ 		var registeredStatusHandlers = [];
/******/ 		var currentStatus = "idle";
/******/ 		
/******/ 		// while downloading
/******/ 		var blockingPromises = 0;
/******/ 		var blockingPromisesWaiting = [];
/******/ 		
/******/ 		// The update info
/******/ 		var currentUpdateApplyHandlers;
/******/ 		var queuedInvalidatedModules;
/******/ 		
/******/ 		__webpack_require__.hmrD = currentModuleData;
/******/ 		
/******/ 		__webpack_require__.i.push(function (options) {
/******/ 			var module = options.module;
/******/ 			var require = createRequire(options.require, options.id);
/******/ 			module.hot = createModuleHotObject(options.id, module);
/******/ 			module.parents = currentParents;
/******/ 			module.children = [];
/******/ 			currentParents = [];
/******/ 			options.require = require;
/******/ 		});
/******/ 		
/******/ 		__webpack_require__.hmrC = {};
/******/ 		__webpack_require__.hmrI = {};
/******/ 		
/******/ 		function createRequire(require, moduleId) {
/******/ 			var me = installedModules[moduleId];
/******/ 			if (!me) return require;
/******/ 			var fn = function (request) {
/******/ 				if (me.hot.active) {
/******/ 					if (installedModules[request]) {
/******/ 						var parents = installedModules[request].parents;
/******/ 						if (parents.indexOf(moduleId) === -1) {
/******/ 							parents.push(moduleId);
/******/ 						}
/******/ 					} else {
/******/ 						currentParents = [moduleId];
/******/ 						currentChildModule = request;
/******/ 					}
/******/ 					if (me.children.indexOf(request) === -1) {
/******/ 						me.children.push(request);
/******/ 					}
/******/ 				} else {
/******/ 					console.warn(
/******/ 						"[HMR] unexpected require(" +
/******/ 							request +
/******/ 							") from disposed module " +
/******/ 							moduleId
/******/ 					);
/******/ 					currentParents = [];
/******/ 				}
/******/ 				return require(request);
/******/ 			};
/******/ 			var createPropertyDescriptor = function (name) {
/******/ 				return {
/******/ 					configurable: true,
/******/ 					enumerable: true,
/******/ 					get: function () {
/******/ 						return require[name];
/******/ 					},
/******/ 					set: function (value) {
/******/ 						require[name] = value;
/******/ 					}
/******/ 				};
/******/ 			};
/******/ 			for (var name in require) {
/******/ 				if (Object.prototype.hasOwnProperty.call(require, name) && name !== "e") {
/******/ 					Object.defineProperty(fn, name, createPropertyDescriptor(name));
/******/ 				}
/******/ 			}
/******/ 			fn.e = function (chunkId, fetchPriority) {
/******/ 				return trackBlockingPromise(require.e(chunkId, fetchPriority));
/******/ 			};
/******/ 			return fn;
/******/ 		}
/******/ 		
/******/ 		function createModuleHotObject(moduleId, me) {
/******/ 			var _main = currentChildModule !== moduleId;
/******/ 			var hot = {
/******/ 				// private stuff
/******/ 				_acceptedDependencies: {},
/******/ 				_acceptedErrorHandlers: {},
/******/ 				_declinedDependencies: {},
/******/ 				_selfAccepted: false,
/******/ 				_selfDeclined: false,
/******/ 				_selfInvalidated: false,
/******/ 				_disposeHandlers: [],
/******/ 				_main: _main,
/******/ 				_requireSelf: function () {
/******/ 					currentParents = me.parents.slice();
/******/ 					currentChildModule = _main ? undefined : moduleId;
/******/ 					__webpack_require__(moduleId);
/******/ 				},
/******/ 		
/******/ 				// Module API
/******/ 				active: true,
/******/ 				accept: function (dep, callback, errorHandler) {
/******/ 					if (dep === undefined) hot._selfAccepted = true;
/******/ 					else if (typeof dep === "function") hot._selfAccepted = dep;
/******/ 					else if (typeof dep === "object" && dep !== null) {
/******/ 						for (var i = 0; i < dep.length; i++) {
/******/ 							hot._acceptedDependencies[dep[i]] = callback || function () {};
/******/ 							hot._acceptedErrorHandlers[dep[i]] = errorHandler;
/******/ 						}
/******/ 					} else {
/******/ 						hot._acceptedDependencies[dep] = callback || function () {};
/******/ 						hot._acceptedErrorHandlers[dep] = errorHandler;
/******/ 					}
/******/ 				},
/******/ 				decline: function (dep) {
/******/ 					if (dep === undefined) hot._selfDeclined = true;
/******/ 					else if (typeof dep === "object" && dep !== null)
/******/ 						for (var i = 0; i < dep.length; i++)
/******/ 							hot._declinedDependencies[dep[i]] = true;
/******/ 					else hot._declinedDependencies[dep] = true;
/******/ 				},
/******/ 				dispose: function (callback) {
/******/ 					hot._disposeHandlers.push(callback);
/******/ 				},
/******/ 				addDisposeHandler: function (callback) {
/******/ 					hot._disposeHandlers.push(callback);
/******/ 				},
/******/ 				removeDisposeHandler: function (callback) {
/******/ 					var idx = hot._disposeHandlers.indexOf(callback);
/******/ 					if (idx >= 0) hot._disposeHandlers.splice(idx, 1);
/******/ 				},
/******/ 				invalidate: function () {
/******/ 					this._selfInvalidated = true;
/******/ 					switch (currentStatus) {
/******/ 						case "idle":
/******/ 							currentUpdateApplyHandlers = [];
/******/ 							Object.keys(__webpack_require__.hmrI).forEach(function (key) {
/******/ 								__webpack_require__.hmrI[key](
/******/ 									moduleId,
/******/ 									currentUpdateApplyHandlers
/******/ 								);
/******/ 							});
/******/ 							setStatus("ready");
/******/ 							break;
/******/ 						case "ready":
/******/ 							Object.keys(__webpack_require__.hmrI).forEach(function (key) {
/******/ 								__webpack_require__.hmrI[key](
/******/ 									moduleId,
/******/ 									currentUpdateApplyHandlers
/******/ 								);
/******/ 							});
/******/ 							break;
/******/ 						case "prepare":
/******/ 						case "check":
/******/ 						case "dispose":
/******/ 						case "apply":
/******/ 							(queuedInvalidatedModules = queuedInvalidatedModules || []).push(
/******/ 								moduleId
/******/ 							);
/******/ 							break;
/******/ 						default:
/******/ 							// ignore requests in error states
/******/ 							break;
/******/ 					}
/******/ 				},
/******/ 		
/******/ 				// Management API
/******/ 				check: hotCheck,
/******/ 				apply: hotApply,
/******/ 				status: function (l) {
/******/ 					if (!l) return currentStatus;
/******/ 					registeredStatusHandlers.push(l);
/******/ 				},
/******/ 				addStatusHandler: function (l) {
/******/ 					registeredStatusHandlers.push(l);
/******/ 				},
/******/ 				removeStatusHandler: function (l) {
/******/ 					var idx = registeredStatusHandlers.indexOf(l);
/******/ 					if (idx >= 0) registeredStatusHandlers.splice(idx, 1);
/******/ 				},
/******/ 		
/******/ 				//inherit from previous dispose call
/******/ 				data: currentModuleData[moduleId]
/******/ 			};
/******/ 			currentChildModule = undefined;
/******/ 			return hot;
/******/ 		}
/******/ 		
/******/ 		function setStatus(newStatus) {
/******/ 			currentStatus = newStatus;
/******/ 			var results = [];
/******/ 		
/******/ 			for (var i = 0; i < registeredStatusHandlers.length; i++)
/******/ 				results[i] = registeredStatusHandlers[i].call(null, newStatus);
/******/ 		
/******/ 			return Promise.all(results).then(function () {});
/******/ 		}
/******/ 		
/******/ 		function unblock() {
/******/ 			if (--blockingPromises === 0) {
/******/ 				setStatus("ready").then(function () {
/******/ 					if (blockingPromises === 0) {
/******/ 						var list = blockingPromisesWaiting;
/******/ 						blockingPromisesWaiting = [];
/******/ 						for (var i = 0; i < list.length; i++) {
/******/ 							list[i]();
/******/ 						}
/******/ 					}
/******/ 				});
/******/ 			}
/******/ 		}
/******/ 		
/******/ 		function trackBlockingPromise(promise) {
/******/ 			switch (currentStatus) {
/******/ 				case "ready":
/******/ 					setStatus("prepare");
/******/ 				/* fallthrough */
/******/ 				case "prepare":
/******/ 					blockingPromises++;
/******/ 					promise.then(unblock, unblock);
/******/ 					return promise;
/******/ 				default:
/******/ 					return promise;
/******/ 			}
/******/ 		}
/******/ 		
/******/ 		function waitForBlockingPromises(fn) {
/******/ 			if (blockingPromises === 0) return fn();
/******/ 			return new Promise(function (resolve) {
/******/ 				blockingPromisesWaiting.push(function () {
/******/ 					resolve(fn());
/******/ 				});
/******/ 			});
/******/ 		}
/******/ 		
/******/ 		function hotCheck(applyOnUpdate) {
/******/ 			if (currentStatus !== "idle") {
/******/ 				throw new Error("check() is only allowed in idle status");
/******/ 			}
/******/ 			return setStatus("check")
/******/ 				.then(__webpack_require__.hmrM)
/******/ 				.then(function (update) {
/******/ 					if (!update) {
/******/ 						return setStatus(applyInvalidatedModules() ? "ready" : "idle").then(
/******/ 							function () {
/******/ 								return null;
/******/ 							}
/******/ 						);
/******/ 					}
/******/ 		
/******/ 					return setStatus("prepare").then(function () {
/******/ 						var updatedModules = [];
/******/ 						currentUpdateApplyHandlers = [];
/******/ 		
/******/ 						return Promise.all(
/******/ 							Object.keys(__webpack_require__.hmrC).reduce(function (
/******/ 								promises,
/******/ 								key
/******/ 							) {
/******/ 								__webpack_require__.hmrC[key](
/******/ 									update.c,
/******/ 									update.r,
/******/ 									update.m,
/******/ 									promises,
/******/ 									currentUpdateApplyHandlers,
/******/ 									updatedModules
/******/ 								);
/******/ 								return promises;
/******/ 							}, [])
/******/ 						).then(function () {
/******/ 							return waitForBlockingPromises(function () {
/******/ 								if (applyOnUpdate) {
/******/ 									return internalApply(applyOnUpdate);
/******/ 								} else {
/******/ 									return setStatus("ready").then(function () {
/******/ 										return updatedModules;
/******/ 									});
/******/ 								}
/******/ 							});
/******/ 						});
/******/ 					});
/******/ 				});
/******/ 		}
/******/ 		
/******/ 		function hotApply(options) {
/******/ 			if (currentStatus !== "ready") {
/******/ 				return Promise.resolve().then(function () {
/******/ 					throw new Error(
/******/ 						"apply() is only allowed in ready status (state: " +
/******/ 							currentStatus +
/******/ 							")"
/******/ 					);
/******/ 				});
/******/ 			}
/******/ 			return internalApply(options);
/******/ 		}
/******/ 		
/******/ 		function internalApply(options) {
/******/ 			options = options || {};
/******/ 		
/******/ 			applyInvalidatedModules();
/******/ 		
/******/ 			var results = currentUpdateApplyHandlers.map(function (handler) {
/******/ 				return handler(options);
/******/ 			});
/******/ 			currentUpdateApplyHandlers = undefined;
/******/ 		
/******/ 			var errors = results
/******/ 				.map(function (r) {
/******/ 					return r.error;
/******/ 				})
/******/ 				.filter(Boolean);
/******/ 		
/******/ 			if (errors.length > 0) {
/******/ 				return setStatus("abort").then(function () {
/******/ 					throw errors[0];
/******/ 				});
/******/ 			}
/******/ 		
/******/ 			// Now in "dispose" phase
/******/ 			var disposePromise = setStatus("dispose");
/******/ 		
/******/ 			results.forEach(function (result) {
/******/ 				if (result.dispose) result.dispose();
/******/ 			});
/******/ 		
/******/ 			// Now in "apply" phase
/******/ 			var applyPromise = setStatus("apply");
/******/ 		
/******/ 			var error;
/******/ 			var reportError = function (err) {
/******/ 				if (!error) error = err;
/******/ 			};
/******/ 		
/******/ 			var outdatedModules = [];
/******/ 			results.forEach(function (result) {
/******/ 				if (result.apply) {
/******/ 					var modules = result.apply(reportError);
/******/ 					if (modules) {
/******/ 						for (var i = 0; i < modules.length; i++) {
/******/ 							outdatedModules.push(modules[i]);
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 			});
/******/ 		
/******/ 			return Promise.all([disposePromise, applyPromise]).then(function () {
/******/ 				// handle errors in accept handlers and self accepted module load
/******/ 				if (error) {
/******/ 					return setStatus("fail").then(function () {
/******/ 						throw error;
/******/ 					});
/******/ 				}
/******/ 		
/******/ 				if (queuedInvalidatedModules) {
/******/ 					return internalApply(options).then(function (list) {
/******/ 						outdatedModules.forEach(function (moduleId) {
/******/ 							if (list.indexOf(moduleId) < 0) list.push(moduleId);
/******/ 						});
/******/ 						return list;
/******/ 					});
/******/ 				}
/******/ 		
/******/ 				return setStatus("idle").then(function () {
/******/ 					return outdatedModules;
/******/ 				});
/******/ 			});
/******/ 		}
/******/ 		
/******/ 		function applyInvalidatedModules() {
/******/ 			if (queuedInvalidatedModules) {
/******/ 				if (!currentUpdateApplyHandlers) currentUpdateApplyHandlers = [];
/******/ 				Object.keys(__webpack_require__.hmrI).forEach(function (key) {
/******/ 					queuedInvalidatedModules.forEach(function (moduleId) {
/******/ 						__webpack_require__.hmrI[key](
/******/ 							moduleId,
/******/ 							currentUpdateApplyHandlers
/******/ 						);
/******/ 					});
/******/ 				});
/******/ 				queuedInvalidatedModules = undefined;
/******/ 				return true;
/******/ 			}
/******/ 		}
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		var scriptUrl;
/******/ 		if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
/******/ 		var document = __webpack_require__.g.document;
/******/ 		if (!scriptUrl && document) {
/******/ 			if (document.currentScript)
/******/ 				scriptUrl = document.currentScript.src;
/******/ 			if (!scriptUrl) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				if(scripts.length) {
/******/ 					var i = scripts.length - 1;
/******/ 					while (i > -1 && (!scriptUrl || !/^http(s?):/.test(scriptUrl))) scriptUrl = scripts[i--].src;
/******/ 				}
/******/ 			}
/******/ 		}
/******/ 		// When supporting browsers where an automatic publicPath is not supported you must specify an output.publicPath manually via configuration
/******/ 		// or pass an empty string ("") and set the __webpack_public_path__ variable from your code to use your own logic.
/******/ 		if (!scriptUrl) throw new Error("Automatic publicPath is not supported in this browser");
/******/ 		scriptUrl = scriptUrl.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
/******/ 		__webpack_require__.p = scriptUrl;
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/importScripts chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded chunks
/******/ 		// "1" means "already loaded"
/******/ 		var installedChunks = __webpack_require__.hmrS_importScripts = __webpack_require__.hmrS_importScripts || {
/******/ 			2: 1
/******/ 		};
/******/ 		
/******/ 		// importScripts chunk loading
/******/ 		var installChunk = (data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			for(var moduleId in moreModules) {
/******/ 				if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 					__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 				}
/******/ 			}
/******/ 			if(runtime) runtime(__webpack_require__);
/******/ 			while(chunkIds.length)
/******/ 				installedChunks[chunkIds.pop()] = 1;
/******/ 			parentChunkLoadingFunction(data);
/******/ 		};
/******/ 		__webpack_require__.f.i = (chunkId, promises) => {
/******/ 			// "1" is the signal for "already loaded"
/******/ 			if(!installedChunks[chunkId]) {
/******/ 				if(true) { // all chunks have JS
/******/ 					importScripts(__webpack_require__.p + __webpack_require__.u(chunkId));
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunknova_spektr"] = self["webpackChunknova_spektr"] || [];
/******/ 		var parentChunkLoadingFunction = chunkLoadingGlobal.push.bind(chunkLoadingGlobal);
/******/ 		chunkLoadingGlobal.push = installChunk;
/******/ 		
/******/ 		function loadUpdateChunk(chunkId, updatedModulesList) {
/******/ 			var success = false;
/******/ 			self["webpackHotUpdatenova_spektr"] = (_, moreModules, runtime) => {
/******/ 				for(var moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						currentUpdate[moduleId] = moreModules[moduleId];
/******/ 						if(updatedModulesList) updatedModulesList.push(moduleId);
/******/ 					}
/******/ 				}
/******/ 				if(runtime) currentUpdateRuntime.push(runtime);
/******/ 				success = true;
/******/ 			};
/******/ 			// start update chunk loading
/******/ 			importScripts(__webpack_require__.p + __webpack_require__.hu(chunkId));
/******/ 			if(!success) throw new Error("Loading update chunk failed for unknown reason");
/******/ 		}
/******/ 		
/******/ 		var currentUpdateChunks;
/******/ 		var currentUpdate;
/******/ 		var currentUpdateRemovedChunks;
/******/ 		var currentUpdateRuntime;
/******/ 		function applyHandler(options) {
/******/ 			if (__webpack_require__.f) delete __webpack_require__.f.importScriptsHmr;
/******/ 			currentUpdateChunks = undefined;
/******/ 			function getAffectedModuleEffects(updateModuleId) {
/******/ 				var outdatedModules = [updateModuleId];
/******/ 				var outdatedDependencies = {};
/******/ 		
/******/ 				var queue = outdatedModules.map(function (id) {
/******/ 					return {
/******/ 						chain: [id],
/******/ 						id: id
/******/ 					};
/******/ 				});
/******/ 				while (queue.length > 0) {
/******/ 					var queueItem = queue.pop();
/******/ 					var moduleId = queueItem.id;
/******/ 					var chain = queueItem.chain;
/******/ 					var module = __webpack_require__.c[moduleId];
/******/ 					if (
/******/ 						!module ||
/******/ 						(module.hot._selfAccepted && !module.hot._selfInvalidated)
/******/ 					)
/******/ 						continue;
/******/ 					if (module.hot._selfDeclined) {
/******/ 						return {
/******/ 							type: "self-declined",
/******/ 							chain: chain,
/******/ 							moduleId: moduleId
/******/ 						};
/******/ 					}
/******/ 					if (module.hot._main) {
/******/ 						return {
/******/ 							type: "unaccepted",
/******/ 							chain: chain,
/******/ 							moduleId: moduleId
/******/ 						};
/******/ 					}
/******/ 					for (var i = 0; i < module.parents.length; i++) {
/******/ 						var parentId = module.parents[i];
/******/ 						var parent = __webpack_require__.c[parentId];
/******/ 						if (!parent) continue;
/******/ 						if (parent.hot._declinedDependencies[moduleId]) {
/******/ 							return {
/******/ 								type: "declined",
/******/ 								chain: chain.concat([parentId]),
/******/ 								moduleId: moduleId,
/******/ 								parentId: parentId
/******/ 							};
/******/ 						}
/******/ 						if (outdatedModules.indexOf(parentId) !== -1) continue;
/******/ 						if (parent.hot._acceptedDependencies[moduleId]) {
/******/ 							if (!outdatedDependencies[parentId])
/******/ 								outdatedDependencies[parentId] = [];
/******/ 							addAllToSet(outdatedDependencies[parentId], [moduleId]);
/******/ 							continue;
/******/ 						}
/******/ 						delete outdatedDependencies[parentId];
/******/ 						outdatedModules.push(parentId);
/******/ 						queue.push({
/******/ 							chain: chain.concat([parentId]),
/******/ 							id: parentId
/******/ 						});
/******/ 					}
/******/ 				}
/******/ 		
/******/ 				return {
/******/ 					type: "accepted",
/******/ 					moduleId: updateModuleId,
/******/ 					outdatedModules: outdatedModules,
/******/ 					outdatedDependencies: outdatedDependencies
/******/ 				};
/******/ 			}
/******/ 		
/******/ 			function addAllToSet(a, b) {
/******/ 				for (var i = 0; i < b.length; i++) {
/******/ 					var item = b[i];
/******/ 					if (a.indexOf(item) === -1) a.push(item);
/******/ 				}
/******/ 			}
/******/ 		
/******/ 			// at begin all updates modules are outdated
/******/ 			// the "outdated" status can propagate to parents if they don't accept the children
/******/ 			var outdatedDependencies = {};
/******/ 			var outdatedModules = [];
/******/ 			var appliedUpdate = {};
/******/ 		
/******/ 			var warnUnexpectedRequire = function warnUnexpectedRequire(module) {
/******/ 				console.warn(
/******/ 					"[HMR] unexpected require(" + module.id + ") to disposed module"
/******/ 				);
/******/ 			};
/******/ 		
/******/ 			for (var moduleId in currentUpdate) {
/******/ 				if (__webpack_require__.o(currentUpdate, moduleId)) {
/******/ 					var newModuleFactory = currentUpdate[moduleId];
/******/ 					/** @type {TODO} */
/******/ 					var result;
/******/ 					if (newModuleFactory) {
/******/ 						result = getAffectedModuleEffects(moduleId);
/******/ 					} else {
/******/ 						result = {
/******/ 							type: "disposed",
/******/ 							moduleId: moduleId
/******/ 						};
/******/ 					}
/******/ 					/** @type {Error|false} */
/******/ 					var abortError = false;
/******/ 					var doApply = false;
/******/ 					var doDispose = false;
/******/ 					var chainInfo = "";
/******/ 					if (result.chain) {
/******/ 						chainInfo = "\nUpdate propagation: " + result.chain.join(" -> ");
/******/ 					}
/******/ 					switch (result.type) {
/******/ 						case "self-declined":
/******/ 							if (options.onDeclined) options.onDeclined(result);
/******/ 							if (!options.ignoreDeclined)
/******/ 								abortError = new Error(
/******/ 									"Aborted because of self decline: " +
/******/ 										result.moduleId +
/******/ 										chainInfo
/******/ 								);
/******/ 							break;
/******/ 						case "declined":
/******/ 							if (options.onDeclined) options.onDeclined(result);
/******/ 							if (!options.ignoreDeclined)
/******/ 								abortError = new Error(
/******/ 									"Aborted because of declined dependency: " +
/******/ 										result.moduleId +
/******/ 										" in " +
/******/ 										result.parentId +
/******/ 										chainInfo
/******/ 								);
/******/ 							break;
/******/ 						case "unaccepted":
/******/ 							if (options.onUnaccepted) options.onUnaccepted(result);
/******/ 							if (!options.ignoreUnaccepted)
/******/ 								abortError = new Error(
/******/ 									"Aborted because " + moduleId + " is not accepted" + chainInfo
/******/ 								);
/******/ 							break;
/******/ 						case "accepted":
/******/ 							if (options.onAccepted) options.onAccepted(result);
/******/ 							doApply = true;
/******/ 							break;
/******/ 						case "disposed":
/******/ 							if (options.onDisposed) options.onDisposed(result);
/******/ 							doDispose = true;
/******/ 							break;
/******/ 						default:
/******/ 							throw new Error("Unexception type " + result.type);
/******/ 					}
/******/ 					if (abortError) {
/******/ 						return {
/******/ 							error: abortError
/******/ 						};
/******/ 					}
/******/ 					if (doApply) {
/******/ 						appliedUpdate[moduleId] = newModuleFactory;
/******/ 						addAllToSet(outdatedModules, result.outdatedModules);
/******/ 						for (moduleId in result.outdatedDependencies) {
/******/ 							if (__webpack_require__.o(result.outdatedDependencies, moduleId)) {
/******/ 								if (!outdatedDependencies[moduleId])
/******/ 									outdatedDependencies[moduleId] = [];
/******/ 								addAllToSet(
/******/ 									outdatedDependencies[moduleId],
/******/ 									result.outdatedDependencies[moduleId]
/******/ 								);
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 					if (doDispose) {
/******/ 						addAllToSet(outdatedModules, [result.moduleId]);
/******/ 						appliedUpdate[moduleId] = warnUnexpectedRequire;
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 			currentUpdate = undefined;
/******/ 		
/******/ 			// Store self accepted outdated modules to require them later by the module system
/******/ 			var outdatedSelfAcceptedModules = [];
/******/ 			for (var j = 0; j < outdatedModules.length; j++) {
/******/ 				var outdatedModuleId = outdatedModules[j];
/******/ 				var module = __webpack_require__.c[outdatedModuleId];
/******/ 				if (
/******/ 					module &&
/******/ 					(module.hot._selfAccepted || module.hot._main) &&
/******/ 					// removed self-accepted modules should not be required
/******/ 					appliedUpdate[outdatedModuleId] !== warnUnexpectedRequire &&
/******/ 					// when called invalidate self-accepting is not possible
/******/ 					!module.hot._selfInvalidated
/******/ 				) {
/******/ 					outdatedSelfAcceptedModules.push({
/******/ 						module: outdatedModuleId,
/******/ 						require: module.hot._requireSelf,
/******/ 						errorHandler: module.hot._selfAccepted
/******/ 					});
/******/ 				}
/******/ 			}
/******/ 		
/******/ 			var moduleOutdatedDependencies;
/******/ 		
/******/ 			return {
/******/ 				dispose: function () {
/******/ 					currentUpdateRemovedChunks.forEach(function (chunkId) {
/******/ 						delete installedChunks[chunkId];
/******/ 					});
/******/ 					currentUpdateRemovedChunks = undefined;
/******/ 		
/******/ 					var idx;
/******/ 					var queue = outdatedModules.slice();
/******/ 					while (queue.length > 0) {
/******/ 						var moduleId = queue.pop();
/******/ 						var module = __webpack_require__.c[moduleId];
/******/ 						if (!module) continue;
/******/ 		
/******/ 						var data = {};
/******/ 		
/******/ 						// Call dispose handlers
/******/ 						var disposeHandlers = module.hot._disposeHandlers;
/******/ 						for (j = 0; j < disposeHandlers.length; j++) {
/******/ 							disposeHandlers[j].call(null, data);
/******/ 						}
/******/ 						__webpack_require__.hmrD[moduleId] = data;
/******/ 		
/******/ 						// disable module (this disables requires from this module)
/******/ 						module.hot.active = false;
/******/ 		
/******/ 						// remove module from cache
/******/ 						delete __webpack_require__.c[moduleId];
/******/ 		
/******/ 						// when disposing there is no need to call dispose handler
/******/ 						delete outdatedDependencies[moduleId];
/******/ 		
/******/ 						// remove "parents" references from all children
/******/ 						for (j = 0; j < module.children.length; j++) {
/******/ 							var child = __webpack_require__.c[module.children[j]];
/******/ 							if (!child) continue;
/******/ 							idx = child.parents.indexOf(moduleId);
/******/ 							if (idx >= 0) {
/******/ 								child.parents.splice(idx, 1);
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					// remove outdated dependency from module children
/******/ 					var dependency;
/******/ 					for (var outdatedModuleId in outdatedDependencies) {
/******/ 						if (__webpack_require__.o(outdatedDependencies, outdatedModuleId)) {
/******/ 							module = __webpack_require__.c[outdatedModuleId];
/******/ 							if (module) {
/******/ 								moduleOutdatedDependencies =
/******/ 									outdatedDependencies[outdatedModuleId];
/******/ 								for (j = 0; j < moduleOutdatedDependencies.length; j++) {
/******/ 									dependency = moduleOutdatedDependencies[j];
/******/ 									idx = module.children.indexOf(dependency);
/******/ 									if (idx >= 0) module.children.splice(idx, 1);
/******/ 								}
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 				},
/******/ 				apply: function (reportError) {
/******/ 					// insert new code
/******/ 					for (var updateModuleId in appliedUpdate) {
/******/ 						if (__webpack_require__.o(appliedUpdate, updateModuleId)) {
/******/ 							__webpack_require__.m[updateModuleId] = appliedUpdate[updateModuleId];
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					// run new runtime modules
/******/ 					for (var i = 0; i < currentUpdateRuntime.length; i++) {
/******/ 						currentUpdateRuntime[i](__webpack_require__);
/******/ 					}
/******/ 		
/******/ 					// call accept handlers
/******/ 					for (var outdatedModuleId in outdatedDependencies) {
/******/ 						if (__webpack_require__.o(outdatedDependencies, outdatedModuleId)) {
/******/ 							var module = __webpack_require__.c[outdatedModuleId];
/******/ 							if (module) {
/******/ 								moduleOutdatedDependencies =
/******/ 									outdatedDependencies[outdatedModuleId];
/******/ 								var callbacks = [];
/******/ 								var errorHandlers = [];
/******/ 								var dependenciesForCallbacks = [];
/******/ 								for (var j = 0; j < moduleOutdatedDependencies.length; j++) {
/******/ 									var dependency = moduleOutdatedDependencies[j];
/******/ 									var acceptCallback =
/******/ 										module.hot._acceptedDependencies[dependency];
/******/ 									var errorHandler =
/******/ 										module.hot._acceptedErrorHandlers[dependency];
/******/ 									if (acceptCallback) {
/******/ 										if (callbacks.indexOf(acceptCallback) !== -1) continue;
/******/ 										callbacks.push(acceptCallback);
/******/ 										errorHandlers.push(errorHandler);
/******/ 										dependenciesForCallbacks.push(dependency);
/******/ 									}
/******/ 								}
/******/ 								for (var k = 0; k < callbacks.length; k++) {
/******/ 									try {
/******/ 										callbacks[k].call(null, moduleOutdatedDependencies);
/******/ 									} catch (err) {
/******/ 										if (typeof errorHandlers[k] === "function") {
/******/ 											try {
/******/ 												errorHandlers[k](err, {
/******/ 													moduleId: outdatedModuleId,
/******/ 													dependencyId: dependenciesForCallbacks[k]
/******/ 												});
/******/ 											} catch (err2) {
/******/ 												if (options.onErrored) {
/******/ 													options.onErrored({
/******/ 														type: "accept-error-handler-errored",
/******/ 														moduleId: outdatedModuleId,
/******/ 														dependencyId: dependenciesForCallbacks[k],
/******/ 														error: err2,
/******/ 														originalError: err
/******/ 													});
/******/ 												}
/******/ 												if (!options.ignoreErrored) {
/******/ 													reportError(err2);
/******/ 													reportError(err);
/******/ 												}
/******/ 											}
/******/ 										} else {
/******/ 											if (options.onErrored) {
/******/ 												options.onErrored({
/******/ 													type: "accept-errored",
/******/ 													moduleId: outdatedModuleId,
/******/ 													dependencyId: dependenciesForCallbacks[k],
/******/ 													error: err
/******/ 												});
/******/ 											}
/******/ 											if (!options.ignoreErrored) {
/******/ 												reportError(err);
/******/ 											}
/******/ 										}
/******/ 									}
/******/ 								}
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					// Load self accepted modules
/******/ 					for (var o = 0; o < outdatedSelfAcceptedModules.length; o++) {
/******/ 						var item = outdatedSelfAcceptedModules[o];
/******/ 						var moduleId = item.module;
/******/ 						try {
/******/ 							item.require(moduleId);
/******/ 						} catch (err) {
/******/ 							if (typeof item.errorHandler === "function") {
/******/ 								try {
/******/ 									item.errorHandler(err, {
/******/ 										moduleId: moduleId,
/******/ 										module: __webpack_require__.c[moduleId]
/******/ 									});
/******/ 								} catch (err2) {
/******/ 									if (options.onErrored) {
/******/ 										options.onErrored({
/******/ 											type: "self-accept-error-handler-errored",
/******/ 											moduleId: moduleId,
/******/ 											error: err2,
/******/ 											originalError: err
/******/ 										});
/******/ 									}
/******/ 									if (!options.ignoreErrored) {
/******/ 										reportError(err2);
/******/ 										reportError(err);
/******/ 									}
/******/ 								}
/******/ 							} else {
/******/ 								if (options.onErrored) {
/******/ 									options.onErrored({
/******/ 										type: "self-accept-errored",
/******/ 										moduleId: moduleId,
/******/ 										error: err
/******/ 									});
/******/ 								}
/******/ 								if (!options.ignoreErrored) {
/******/ 									reportError(err);
/******/ 								}
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					return outdatedModules;
/******/ 				}
/******/ 			};
/******/ 		}
/******/ 		__webpack_require__.hmrI.importScripts = function (moduleId, applyHandlers) {
/******/ 			if (!currentUpdate) {
/******/ 				currentUpdate = {};
/******/ 				currentUpdateRuntime = [];
/******/ 				currentUpdateRemovedChunks = [];
/******/ 				applyHandlers.push(applyHandler);
/******/ 			}
/******/ 			if (!__webpack_require__.o(currentUpdate, moduleId)) {
/******/ 				currentUpdate[moduleId] = __webpack_require__.m[moduleId];
/******/ 			}
/******/ 		};
/******/ 		__webpack_require__.hmrC.importScripts = function (
/******/ 			chunkIds,
/******/ 			removedChunks,
/******/ 			removedModules,
/******/ 			promises,
/******/ 			applyHandlers,
/******/ 			updatedModulesList
/******/ 		) {
/******/ 			applyHandlers.push(applyHandler);
/******/ 			currentUpdateChunks = {};
/******/ 			currentUpdateRemovedChunks = removedChunks;
/******/ 			currentUpdate = removedModules.reduce(function (obj, key) {
/******/ 				obj[key] = false;
/******/ 				return obj;
/******/ 			}, {});
/******/ 			currentUpdateRuntime = [];
/******/ 			chunkIds.forEach(function (chunkId) {
/******/ 				if (
/******/ 					__webpack_require__.o(installedChunks, chunkId) &&
/******/ 					installedChunks[chunkId] !== undefined
/******/ 				) {
/******/ 					promises.push(loadUpdateChunk(chunkId, updatedModulesList));
/******/ 					currentUpdateChunks[chunkId] = true;
/******/ 				} else {
/******/ 					currentUpdateChunks[chunkId] = false;
/******/ 				}
/******/ 			});
/******/ 			if (__webpack_require__.f) {
/******/ 				__webpack_require__.f.importScriptsHmr = function (chunkId, promises) {
/******/ 					if (
/******/ 						currentUpdateChunks &&
/******/ 						__webpack_require__.o(currentUpdateChunks, chunkId) &&
/******/ 						!currentUpdateChunks[chunkId]
/******/ 					) {
/******/ 						promises.push(loadUpdateChunk(chunkId));
/******/ 						currentUpdateChunks[chunkId] = true;
/******/ 					}
/******/ 				};
/******/ 			}
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.hmrM = () => {
/******/ 			if (typeof fetch === "undefined") throw new Error("No browser support: need fetch API");
/******/ 			return fetch(__webpack_require__.p + __webpack_require__.hmrF()).then((response) => {
/******/ 				if(response.status === 404) return; // no update available
/******/ 				if(!response.ok) throw new Error("Failed to fetch update manifest " + response.statusText);
/******/ 				return response.json();
/******/ 			});
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/startup chunk dependencies */
/******/ 	(() => {
/******/ 		var next = __webpack_require__.x;
/******/ 		__webpack_require__.x = () => {
/******/ 			return __webpack_require__.e(1).then(next);
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// module cache are used so entry inlining is disabled
/******/ 	// run startup
/******/ 	var __webpack_exports__ = __webpack_require__.x();
/******/ 	
/******/ })()
;